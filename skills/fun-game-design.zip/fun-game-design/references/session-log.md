# Session log: the Daphne & Vienna game (Sep 2026)

Use this when continuing the project. It records what was built and the user's verdict on each.

## The real brief (learned late)
- Daphne is real (the user's partner). Vienna is her real cat. Vienna had an eye infection and
  her eyes were surgically removed. She is blind.
- The user wants: a game that is FUN and genuinely CHALLENGING, yet CALM (no anxiety),
  with nice music and sound effects. Mobile-first, playable in the browser.
- The user prefers clever puzzles (think, then solve) over action, chaos or pure cozy.
- Style: bright, soft, easy on the eyes. No dark, fog, glow or neon.

## What was tried and the user's verdict (chronological)
| # | Concept | Verdict |
|---|---|---|
| 1-8 | Orbit Hop, Stardrop (merge), Lanebreak v1/v2 (card battler), Novaflip, Arrow Clash, Flock (puzzle), Flock: Storm Run | boring / ugly / nothing new |
| 9 | Daphne & Miso roguelike deckbuilder | "extremely confusing, nobody understands" |
| 10 | Miso in the Dark (push-your-luck card rules) v1-v2 | boring, broken, rules confusing |
| 11 | Follow My Voice (co-op board game, one player blind) | "horrible, boring" |
| 12 | ECHO echolocation adventure v1 | ugly, too easy |
| 13 | ECHO v2: stealth, hearing AI | "full of anxiety" |
| 14 | ECHO v3: calm, no threats | room doesn't look like a room |
| 15 | ECHO v4-v5: illustrated / Kenney pixel rooms | "100 beds in a room", eyes hurt, boring |
| 16 | Nights at Home (Trust/Calm loop) | "fully broken" (dialogue walls, camera void), then boring |
| 17 | Don't Notice (tidy before the owner returns) v1-v4 | better graphics; user scored 2.5 while Claude self-scored 8.0 |
| 18 | Into the Carrier (rules-based cat puzzle, generated levels) | "stupid, repetitive, nothing I haven't played" |
| 19 | Vienna: story vignettes, 7 scenes | "better", but "not challenging, very boring" |
| 20 | Vienna + 3 rounds and stars per scene | "not challenging at all, extremely boring" |

## Where it stands
- Best-received so far: Vienna (story, real characters, calm audio) and the bright art of
  Don't Notice. Both still judged boring.
- Unanswered, and needed before the next build: 1-3 games the user actually enjoys playing.
- Next step: Phase 1 discovery (SKILL.md). Get reference games, then prototype ONE Vienna scene
  with a hand-authored puzzle that has a real "aha" moment, and get the user's 0-10 score
  before building more.
