---
name: "boardgame-builder"
description: Turn a published board game into a playable single-file browser game with faithful mechanics, original names and art, a computer opponent for every side, and automated balance testing. Use whenever the user gives a BoardGameGeek link (boardgamegeek.com/boardgame/...), names a board or card game and asks to "make it", "build it", "recreate it", "clone it", "make a playable version", or wants a digital version of a tabletop game, even if they don't say "skill" or "board game". Also use when improving, rebalancing or restyling a game built this way.
---

# Board game builder

Build a fun, faithful, playable browser version of a real board game in one HTML file, then prove it works with a headless "gauntlet" of computer-vs-computer games before handing it over.

The single most important lesson: **people want the real game.** Every time a version was simplified ("one unit type, 15 minutes"), the user called it boring. Implement the actual rules from the rulebook; simplify the *interface*, never the *game*.

## Workflow

Do the steps in order. Don't stop to ask permission between them; the user prefers direct execution and a finished result.

### 1. Research the rules (never from memory alone)
- `web_fetch` the BGG page the user gave for player count, playtime, mechanics list and weight.
- `web_search` for the official rulebook (publisher site PDF, "<game> rules pdf") and fetch it. If the PDF can't be fetched, use two independent rules summaries and cross-check them.
- Write a rules sheet in `/home/claude/<slug>/rules-notes.md`: components, setup, turn structure, every action, every victory/loss condition, and exact numbers (dice faces, costs, hand limits, track lengths). Mark anything you had to guess.
- If the rules are huge (e.g. War of the Ring), keep every system that creates decisions and tension, and cut only pure bookkeeping. List what you cut, to report honestly later.

### 2. Handle copyright before writing anything
Read `references/ip-rules.md`. In short: mechanics, numbers and structure are fine to copy exactly; names, characters, card text, board art, logos and iconic designs are not. Rename everything (game title, factions, characters, places, cards) with original names that keep the same *role* (the "hidden ring-bearer" stays a hidden bearer, but is called something new). Write all card text yourself. Draw all art yourself in SVG/CSS. Tell the user once, in one line, that names and art are original for copyright reasons.

### 3. Pick a look once, up front
Ugly graphics were the second biggest complaint. Use `ask_user_input_v0` with 3–4 concrete art directions matched to the game's theme (for King of Tokyo: "Retro kaiju comic", "Neon arcade", "Toy-box plastic", "Painted poster"). Then follow `references/visual-style.md`. Never ship default grey boxes, plain circles on a blank background, or convex-hull "blobs".

For music, sound, 3D models, textures, icons and fonts, read `references/free-assets.md` first. Generate procedurally where you can. Otherwise use only CC0 (Kenney, Quaternius, KayKit, Poly Haven, ambientCG) or CC-BY assets with a Credits entry. Never use NC, ND or "personal use" assets. Log every asset in `ASSETS.md`, and embed it the way that page says: claude.ai artifacts block images, audio and models from other hosts.

### 4. Build the engine
Read `references/architecture.md` and follow its structure: one self-contained HTML file built from `head.html` (styles) + `body.html` (markup + script) so edits stay small. It must include:
- the full rules engine, with state in one serialisable object `G`;
- a computer player for **every** side/seat;
- modes: human vs computer (each side), hot-seat, and watch computer-vs-computer;
- on-screen dice/cards/results that players can *see* (roll overlays, revealed tiles), not just log lines;
- a guided tour (5–8 steps), a rules modal, a map/legend, a chronicle log, and a save via localStorage;
- the **test hooks** listed in `references/architecture.md` (`ANIM`, `AIDELAY`, `newGame('ai')`, `G.winner`, `G.winText`, `G.turn`, `G.log`, `UI.choice/roll/pick/busy`), which the scripts below depend on.

### 5. Run the gauntlet loop until it holds up
Read `references/balance-playbook.md`. Then loop:
1. `node scripts/gauntlet.js <file.html> 20` in parallel batches (see below) — errors, stalls, win split, endings, game length.
2. Change **one** balance lever, re-run at least 60 games, keep or revert.
3. `node scripts/uiclick.js <file.html>` — a random clicker plays every human flow in every mode, with and without animation. Must end with 0 errors, 0 stalls.
4. `node scripts/render.js <file.html> out.png` then `view` the PNG. Fix clipped tokens, overlapping labels, and anything ugly.

Targets before shipping: 0 errors; 0 stalls; each side wins 40–60% between computer players; every victory condition actually happens; average game length within the box playtime (converted to turns); dice/cards visibly used every turn.

Tool limits: any single command is killed at 300 seconds. Run 3–4 batches of 20 games in parallel with `&` and `wait`, write results to files, and read them in a separate command. Install once: `cd /home/claude && npm i jsdom@24 @resvg/resvg-js`.

### 6. Score honestly, then deliver
Score against `references/rubric.md`. Never claim 9/10 without the evidence the rubric asks for; state exactly what's missing. Then:
- `Artifact` publish (reuse the same `url` for updates; set a fitting emoji favicon), **and**
- `present_files` the HTML as well, because the artifact domain can fail on some corporate networks.

Reply tersely: what changed, the gauntlet numbers (a small table), honest score, what's left, and how the user can test (modes to try, what to report).

## Iterating on feedback
- The user swears when frustrated; treat it as a precise bug report, not tone. Find the real cause (usually: too simplified, ugly, unclear what to do) and fix that, rather than polishing around it.
- Rebuild rather than patch when the foundation is wrong (e.g. simplified rules). Say so in one line.
- Keep old versions as `<slug>-v1.html` etc. in `/home/claude`.
- If the work won't fit in one turn, stop at a safe point, keep the file consistent, and say exactly what's done and what's next, so "continue" picks up cleanly.

## Game-type notes
Different families need different centres of gravity. See the "Game families" section of `references/architecture.md` (dice-chuckers like King of Tokyo, map/area control like War of the Ring, deck-builders, worker placement, co-ops, hidden-information games).
