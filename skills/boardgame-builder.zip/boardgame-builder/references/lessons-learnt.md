# Lessons learnt (Game Night Shelf, 9 games, Sept–Oct 2026)

These came from building and iterating Crown City Smash (King of Tokyo), Nebula Aces (X-Wing 1e), Doorkick Dungeon (Munchkin), Shipwreck Isle (Robinson Crusoe), Sands of Qamar (Five Tribes), Sunglaze (Azul) and Rampart & Vine (Carcassonne) with one demanding user. Each item is a complaint or a bug that really happened. Read this list before starting, and again before you deliver.

## What the user actually asks for, in the order the requests arrived
1. **"The real game" with every expansion.** Simplified versions were called boring every time. Do the research first and record every card, number and expansion.
2. **A card and token list inside the system:** a reference drawer in each game and a shared reference page.
3. **Board-first layout:** "I have to scroll, text overlaps the board, use popups that close". See `layout-shell.md`.
4. **Learnable by a newcomer:** "very confusing… the rounds and steps need to be planned better". See `newcomer-ux.md`.
5. **AAA look:** "more AAA games rather than sloppy objects and drawings". See `graphics-aaa.md`.
6. **Real sound and music, free:** CC0 samples, with the synth kept as fallback. See `audio-perf.md`.
7. **Works on real devices:** a speed tool, auto quality and an idle saver. See `audio-perf.md`.
8. **Free hosting and online play with friends:** GitHub Pages plus WebRTC peer-to-peer. See `online-p2p.md` and `delivery.md`.
9. **A good-looking shelf:** real screenshots as covers, not drawn placeholders, and every game listed, including ones built elsewhere.

Plan for all nine from day one. Retrofitting each one across seven games cost far more than building it in would have.

## Rules fidelity
- Research with an agent that fetches the rulebook, the FAQ and the BGG forums, and writes `rules-notes.md` with a **Confirmed vs. guessed** section plus JSON data files (cards, missions, tiles). Real names go in `ref` fields only, and the raw research is never committed.
- Write a rules test per tricky rule (`rules-test.js`). An audit agent found real rule errors in two shipped games. Run an independent "rules audit" pass against the rulebook before you call a game done.
- **Phase names drift.** A power checked `G.phase==='move'` while the real phase was `'turn'`, so it never fired. Only a coverage run catches this.
- **Conserve components.** Use an invariant that every tile or card is in exactly one place, checked after every move in the coverage test. It caught a card that was never discarded and one that was discarded twice.
- **No functions in `G`.** Pending questions are `{h:'handlerKey', d:{...}}`. Closures break save/load, the network sync and host migration.
- **Stalls come from "can't legally do anything".** Look up what the rules say for that case, implement it, and list it as an assumption if it's unclear.

## Interface and flow
- **The dock always says what the game is waiting for**, in plain words, with a button for every option. Never make the player guess the next click.
- **Turn complex rounds into guided steps:** a round roadmap, one phase card at a time with Continue, wizards for planning (needs → assign → risks → confirm), and a recommended option with "why". "Guide full/light" lets veterans turn it down.
- **Hot-seat "pass the device" screens** are needed for hidden information, but must never appear online.
- **Don't stack popups.** The tour, a question and the computer's roll appearing together on turn 1 confused the reviewer. Queue them.
- **No hover lifts on clickable things.** An element that moves away from the pointer on `:hover` causes a hover/unhover loop that made frames 6× slower and stalled a test. Use an invisible hit area if you want a lift effect.
- **`[hidden]{display:none!important}`.** A `display:flex` rule on a hidden overlay once covered the whole 3D board.

## Graphics
- Ask once for an art direction (3 concrete options). Then build tokens, materials and lighting to the brief in `graphics-aaa.md`.
- A Graphics setting (Auto/High/Medium/Low, saved per device). Auto picks Low on software GPUs: detect SwiftShader/llvmpipe from the `WEBGL_debug_renderer_info` string.
- Always keep a 2D fallback board: jsdom has no WebGL, and the click tests play through it.

## Testing (also see `testing.md`)
- **Four test layers per game:**
  - gauntlet: computer vs computer;
  - coverage: random + AI play with invariants checked after every move;
  - jsdom clicker: real buttons only, in every mode;
  - Playwright layout check: real WebGL at 4 sizes, with `elementFromPoint` showing the board is uncovered.
- **Look at the screenshots yourself.** Several "PROBLEMS 0" builds still had ugly overlaps that only a human-style look caught.
- **The sandbox is slow.** It uses SwiftShader, so 3D frames take 50–200 ms, and the load average was 25+ when 6 agents ran at once. Real-time countdowns and animations crawl, so timeouts need to be generous (`setDefaultTimeout(150000)`). Fake page loads with `route()` to `https://gns.test/` and abort Google Fonts, or `load` never fires.
- **Commands are killed after ~5 min.** Run long jobs in the background, write their output to files, and read the files afterwards.

## Working with agents
- **One brief file per kind of work** (`BRIEF-games.md`, `BRIEF-graphics.md`, `BRIEF-perf-audio.md`, `BRIEF-online.md`). Each agent prompt then says "follow the brief, plus these game-specific details". The briefs are in `assets/briefs/`.
- **Run at most 6 heavy agents at once.** More than that and Playwright timeouts begin to look like bugs.
- **Give each parallel agent its own resources** (relay ports 17702–17707, its own folder). Tell agents never to touch shared modules; they propose patches instead, and you apply them once.
- **The container can restart.** Background agents and jobs die, but the files survive. Resume each agent with SendMessage and tell it to check its state and re-run what was killed.
- **Never `pkill -f <pattern>`** from a shell whose own command line contains the pattern: it kills itself (exit 144).
- **Verify every agent report.** One "bad actions changed the state" result was the test script sending a legal move. Re-run the critical checks yourself before you claim anything.

## Delivery
- See `delivery.md`. In short:
  - **claude.ai artifact:** read the live version before republishing. The shelf hosts each game as a supporting file.
  - **GitHub Pages:** the repo's Settings → Pages → Source must be set to "GitHub Actions", and the branch allowed in the `github-pages` environment. Only the repo owner can do this.
  - **Source of truth:** keep the latest copy of games made in other sessions (e.g. Mainhattan Overdrive) as their standalone artifact. Don't copy from the shelf, which may be stale.
- **Report honestly.** State what was not tested (real networks, real GPUs, real ears) and any flaky area (online rejoin) with numbers.
