# Honest scoring rubric (10 points)

Score each line 0–1 (half points allowed). Only count a point with the evidence listed.

| # | Criterion | Evidence required |
|---|---|---|
| 1 | Faithful rules | Every system in rules-notes.md is implemented or listed as cut; no invented core mechanics |
| 2 | Runs clean | Gauntlet ≥100 games: 0 errors, 0 stalls |
| 3 | Human flows work | uiclick.js in every mode, with and without animation: 0 errors, 0 stalls, every action/modal seen |
| 4 | Balance | Computer vs computer: each side 40–60% over ≥100 games |
| 5 | Variety | Every victory condition occurs; no single ending > 60% of games |
| 6 | Pacing | Average length within the box playtime; no game shorter than half of it |
| 7 | Visibility | Dice, cards, tiles and results shown on screen when they happen; you can follow the game without reading the log |
| 8 | Looks good | Screenshots at 4 sizes viewed: no clipping or overlaps, AAA brief met (lighting, materials, sculpted pieces), board-first layout check PROBLEMS 0 |
| 9 | Learnable | Dock always says what to do; round roadmap and guided steps; card reference drawer; a newcomer-review pass done and fixed |
| 10 | Played by a human | The user has played a full game and their feedback is fixed |

Point 10 can't be earned by Claude alone, so a fresh build tops out at 9. Say which points are missing and why.


Also report, but don't score: real audio (CC0, credited), the speed tool, online play tested over a local relay (including leave, rejoin and bad moves), and what was **not** tested (real networks, real GPUs, listening by ear).
