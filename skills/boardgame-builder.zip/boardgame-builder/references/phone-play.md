# Phone play (board first, tap to play, pop-ups)

A board that fits a phone is not the same as a game you can play on a phone. Passing the 390x844 layout check gave Tidewake 16 px squares in landscape; users could not play it. Build a separate phone mode.

Goal: every game is comfortable to PLAY on a phone, portrait and landscape. The board is the main thing; decisions come in small pop-ups and step cards next to it. Rules, engine, AI, online protocol stay unchanged.

Reference implementation: <repo>/games-src/tidewake/game/
  ui7.js (phone module), end of head.html (html.ph CSS), body.html (#ps strip, #ppop pop-up, #pc card), lay-phone.js (test),
  UI-REPORT.md section "Phone layout" (read it first). Live: games/tidewake/index.html.

## Rules
1. Trigger: add class `ph` on <html> when short side <= 500 px, OR (pointer:coarse AND short side <= 600). `?phone=1` / `?phone=0` force it.
   Add `ph-p` / `ph-l` for portrait / landscape; re-evaluate on resize/orientationchange. Every new CSS rule starts with `html.ph` so desktop and the 768x1024 tablet are untouched.
2. Board size: the board (play area) gets >= 0.85 of the short side. Portrait: full width under a slim 44 px icon bar. Landscape: full height on the left; bar + controls in a right rail. No page scroll ever (check documentElement scroll sizes, drawers included).
   3D games: a flatter / top-down phone camera framed to the play area (crop decorative margins). 2D games: scale the board SVG/canvas to fill.
   Large maps (tile-laying, space): fit-to-board by default + pinch/drag or +/- zoom + a "center on me / last move" button.
3. Tap to play: the human acts by tapping the board (pieces, squares, cards on the table). A tap opens a pop-up with that thing's choices (big buttons, a recommended one marked, a preview where useful). Close with x, Esc, or tap outside. Pop-ups live in the free zone next to the board (under it in portrait, right rail in landscape) so they never cover what you are deciding about. Hands of cards: a compact fan/strip; tap a card -> enlarged card pop-up with Play / Discard etc.
4. One thing at a time: coach tips, dice/roll results, event cards, interrupts, pass-the-device, end of game show as ONE card with Continue (priority queue, nothing stacks). Re-use the existing dock HTML (clone it, keep data-a handlers) rather than re-implementing actions.
5. Declutter: hide floating name tags/labels on the board on phones; tap a piece -> info pop-up. Top bar = icon buttons (aria-label) + one compact status chip.
6. Tap targets >= 44 px (bar, strip, pop-ups, cards). Text >= 13 px. Respect safe-area insets (env()).
7. Hidden information: in hot-seat/online, pop-ups/strip only for the seat holding the device; keep data-owner on hands so existing hidden-hand checks still work.
8. Keep every existing test hook (ANIM, AIDELAY, newGame, G, UI.*) working.

## Process (do it in this order)
a. Copy the game source to your work dir under $SP/phone/<slug>/ and build it. Check your build matches the live file games/<slug>/index.html (diff, or same size); if not, tell me in the report and use the live-equivalent source.
b. Measure BEFORE at 390x844, 844x390, 360x740, 740x360 (isMobile+hasTouch, real WebGL via SwiftShader: --use-gl=angle --use-angle=swiftshader --enable-unsafe-swiftshader). Record board px and the size of the smallest thing you must tap. Take screenshots and LOOK at them (Read the PNG).
c. Implement. Prefer one new phone module file + one CSS block + small hooks.
d. Write/extend `lay-phone.js` for this game (model it on tidewake's): no scroll, board ratio >= 0.85 short side, all board targets inside the board and hit-testing to it (elementFromPoint) with each pop-up/card open, pop-up never overlaps the thing it is about, a full human turn done only by touch taps through board + pop-ups, tap targets >= 44 px, 0 console errors. Run all 4 phone sizes.
e. Regression: the game's existing desktop layout test at 1366x768, 1920x1080, 768x1024 stays at 0 problems with the same board share; the clicker (add phone configs with ?phone=1) 0 errors 0 hidden-hand; one p2p online run if the game has p2p-<x>.js in games-src/net (it uses a local relay games-src/net/relay.js).
f. Look at your phone screenshots in both orientations and fix anything ugly/clipped/unreadable. Iterate.

## Constraints
- Machine has 4 CPU cores shared with other agents: run Playwright one size at a time, use graphics Low / ANIM=0 where possible, wrap every command in `timeout 280`, run long things in background writing to files.
- Any single command is killed at 300 s.
- Only touch files in YOUR work dir. Do NOT edit the repo, do NOT git commit or push. The main session deploys.
- Do not `rm -rf` globs; use fresh dirs instead.
- Nobody tests on a real phone: say so honestly; no claims beyond what tests show.

## Report (final message, short)
Before -> after board px per size (and smallest tap target), what changed for the player, test numbers, known gaps, the exact list of changed/new files in your work dir and the built HTML path.
